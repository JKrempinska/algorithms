import re

def check_tags(path):
    with open('unpaired_tags.txt') as u:
        unpaired = u.readlines()
    for i in range(len(unpaired)):
        unpaired[i] = unpaired[i].replace('\n','')

    with open(path) as f:
        content = f.readlines()

    tags_pattern = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>"
    tag_match = re.compile(tags_pattern)
    errors = 0
    for i in range(len(content)):
        match = re.search(tag_match,content[i])
        if match:
            unpaired_tags = 0
            for j in range(len(unpaired)):
                is_unpaired = re.findall(unpaired[j], match.group())
                if is_unpaired:
                    unpaired_tags += 1
            if unpaired_tags != 0:
                i += 1
            else:
                tag = match.group()
                if tag[1] == '/':
                    tag = tag.replace('/','')
                    tag = tag.replace('>','')
                    tag = tag.lower()
                    counter = 0
                    for k in range(i):
                        is_tag_open = re.findall(tag, content[k])
                        if is_tag_open:
                            counter += 1
                    if counter == 0:
                        errors += 1
                else:
                    head, sep, tail = tag.partition(' ')
                    head = head.replace('<','')
                    head = head.replace('>','')
                    head = head.lower()
                    tag = '</' + head + '>'
                    counter = 0
                    for k in range(i,len(content)):
                        is_tag_closed = re.findall(tag, content[k])
                        if is_tag_closed:
                            counter += 1
                    if counter == 0:
                        errors += 1
        else:
            i += 1
    print(errors)
    if errors != 0:
        print('Błąd')
            



check_tags('sample3.txt')
