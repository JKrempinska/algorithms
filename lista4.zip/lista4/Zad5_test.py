from Zad5 import build_tree
from Zad5 import tokenize

expression = input('Podaj wyrażenie:')
expression = build_tree(tokenize(expression))

derivative_expression = expression.derivative()

print("\nPochodna wyrażenia:")
print(derivative_expression.to_string())